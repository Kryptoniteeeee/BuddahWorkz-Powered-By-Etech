	<div class="testimonial">	
					<div class="caption_index_2">title</div>
					<div class="testimonial_div">
					<p>
					na
					</p>
					</div>
					<div class="testimonial_div1">
						<p>
na
					</p>
					</div>
					</div>
					<div class="contact_us">
						<div class="caption_index_2">VISIT OUR OFFICE</div>	
						<p>Office Hours</p>
						<p>Monday - Thursday (8:00 am to 5:00 pm)</p>
						<p>Monday - Thursday (8:00 am to 5:00 pm)</p>
						
					</div>
					<div class="site_map">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3863.293775734533!2d120.97851267497136!3d14.467812886002935!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397cda040e00d2f%3A0x95c9d248d1bbd898!2sBuddahWorkz!5e0!3m2!1sen!2sph!4v1684853170543!5m2!1sen!2sph" width="350" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </iframe>
					</div>