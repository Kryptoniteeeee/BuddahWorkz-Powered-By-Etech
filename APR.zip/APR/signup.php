
<html>
	<head>
		<title>BuddahWorkz Powered By Etech - Las Piñas</title>

		<link href="img/log.jpg" rel="icon">
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	<link rel="stylesheet" type="text/css" href="stylelish.css">

	</head>
	<body >
	<body class="is-preload landing" >
		<div id="page-wrapper"> 

			<!-- Header -->
				<header id="header">
					<h1 id="logo"><a href="index.php">BuddahWorkz</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>

						</ul>
							
					</nav>
				</header>

  
					
<div class="login_sign_up">
		<a rel="tooltip"  data-placement="left" title="Click Here to Login" id="login" href="login.php" 	 class="btn btn-info btn-large"><i class="icon-signin icon-large"></i>&nbsp;Login</a>
</div>

				
								

<div class="signup_container">		
<?php include('signup_form.php'); ?>	
</div>
		
		</div>
			
			
		<!-- Scripts -->
				<script src="assets/js/jquery.min.js"></script>
				<script src="assets/js/jquery.scrolly.min.js"></script>
				<script src="assets/js/jquery.dropotron.min.js"></script>
				<script src="assets/js/jquery.scrollex.min.js"></script>
				<script src="assets/js/browser.min.js"></script>
				<script src="assets/js/breakpoints.min.js"></script>
				<script src="assets/js/util.js"></script>
				<script src="assets/js/main.js"></script>

		</body>
	</html>
			
	