<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" href="dropdown.css" />
</head>
<body>
<header>
	<nav>
		<h1 class="logo"></h1>
		<ul class="menu">
			<li><a href="#">Services</a>
			      <ul class="submenu">
			      	<li><a href="">s</a></li>
			      		<ul class="submenu2">
			      			<li><a href="">sv</a></li>
			      				<li><a href="">sad</a></li>
			      		</ul>
			      		<li><a href="">a</a></li>
			      </ul>
			  </li>
            </ul>

</li>
	</nav>
</header>
</body>
</html>