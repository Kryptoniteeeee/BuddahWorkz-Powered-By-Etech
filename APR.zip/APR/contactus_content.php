
<div class="alert alert-info"><strong>Contact US</strong></div>
<div class="about">
<p>
	.
</p>
<p>
.
</p>
</div>
