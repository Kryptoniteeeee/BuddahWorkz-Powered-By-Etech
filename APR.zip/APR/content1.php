	<div class="text_content">
					<p>
	n.a

					</p>
					</div>